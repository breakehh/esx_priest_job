Config = {}

Config.DrawDistance 			  = 100.0
Config.MarkerType    			  = 1
Config.MarkerSize   			  = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 255, g = 255, b = 255 }
Config.MarkerDeletersColor        = { r = 255, g = 0, b = 0 }

Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- enable if you're using esx_identity
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false -- enable if you're using esx_license

Config.EnableHandcuffTimer        = false -- enable handcuff timer? will unrestrain player after the time ends
Config.HandcuffTimer              = 10 * 60000 -- 10 mins

Config.EnableJobBlip              = true -- enable blips for colleagues, requires esx_society
Config.EnablePoliceFine           = false -- enable fine, requires esx_policejob

Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.churchStations = {
	
	Church = {

		Blip = {
			Pos     = { x = -1680.96, y = -291.96, z = 51.88 },
			Sprite  = 305,
			Display = 4,
			Scale   = 0.8,
			Colour  = 28,
		},

		-- https://wiki.rage.mp/index.php?title=Weapons
		AuthorizedWeapons = {
			{ name = 'WEAPON_FLASHLIGHT',       price = 80 },
		},

		Cloakrooms = {
			{ x = -1682.06, y = -286.31, z = 50.30 },
		},
		
		Armories = {
			{ x = -1677.1, y = -277.74, z = 50.30 },
		},

		Vehicles = {
			{
				Spawner    = { x = -1675.84, y = -298.79, z = 50.90 },
				SpawnPoints = {
					{ x = -1675.84, y = -298.79, z = 50.90, heading = 340.8, radius = 6.0 },
				}
			},
		},

		VehicleDeleters = {
			{ x = -1672.27, y = -301.36, z = 50.90 },
		},
		
		BossActions = {
			{ x = -1679.96, y = -283.53, z = 51.0 },
		},
		
		Elevator = {
			{
				Top = { x = 136.093, y = -761.823, z = 24100.152 },
				Down = { x = 136.093, y = -761.809, z = 44000.752 },
				Parking = { x = 65.447, y = -749.675, z = 30000.634 }
			}
		},

	},

}

-- https://wiki.rage.mp/index.php?title=Vehicles
Config.AuthorizedVehicles = {
	Shared = {
		{
			model = 'romero',
			label = 'Funeral Romero'
		},
		{
			model = 'xyz',
			label = 'fill in according to yourself'
		}
	},

	ministrant = {

	},

	vboss = {

	},

	boss = {

	}
}

-- Look in skinchanger/client/main.lua for more elements.
Config.Uniforms = {

	ministrant_wear = {
		male = {
			['tshirt_1'] = 130,
			['tshirt_2'] = 0,
			['torso_1'] = 111,
			['torso_2'] = 3,
			['decals_1'] = 0,
			['decals_2'] = 0,
			['arms'] = 33,
			['arms_2'] = 0,
			['pants_1'] = 24,
			['pants_2'] = 0,
			['shoes_1'] = 40,
			['shoes_2'] = 9,
			['helmet_1'] = -1,
			['helmet_2'] = 0,
			['chain_1'] = 128,
			['chain_2'] = 0,
			['ears_1'] = -1,
			['ears_2'] = 0,
			['mask_1'] = 121,
			['mask_2'] = 0
		},
		female = {
			['tshirt_1'] = 160,
			['tshirt_2'] = 0,
			['torso_1'] = 136,
			['torso_2'] = 3,
			['decals_1'] = 0,
			['decals_2'] = 0,
			['arms'] = 36,
			['arms_2'] = 0,
			['pants_1'] = 37,
			['pants_2'] = 0,
			['shoes_1'] = 29,
			['shoes_2'] = 0,
			['helmet_1'] = -1,
			['helmet_2'] = 0,
			['chain_1'] = 98,
			['chain_2'] = 0,
			['ears_1'] = -1,
			['ears_2'] = 0,
			['mask_1'] = 121,
			['mask_2'] = 0
		}
	},

	vboss_wear = {
		male = {
			['tshirt_1'] = 130,
			['tshirt_2'] = 0,
			['torso_1'] = 111,
			['torso_2'] = 3,
			['decals_1'] = 0,
			['decals_2'] = 0,
			['arms'] = 33,
			['arms_2'] = 0,
			['pants_1'] = 24,
			['pants_2'] = 0,
			['shoes_1'] = 40,
			['shoes_2'] = 9,
			['helmet_1'] = -1,
			['helmet_2'] = 0,
			['chain_1'] = 128,
			['chain_2'] = 0,
			['ears_1'] = -1,
			['ears_2'] = 0,
			['mask_1'] = 121,
			['mask_2'] = 0
		},
		female = {
			['tshirt_1'] = 160,
			['tshirt_2'] = 0,
			['torso_1'] = 136,
			['torso_2'] = 3,
			['decals_1'] = 0,
			['decals_2'] = 0,
			['arms'] = 36,
			['arms_2'] = 0,
			['pants_1'] = 37,
			['pants_2'] = 0,
			['shoes_1'] = 29,
			['shoes_2'] = 0,
			['helmet_1'] = -1,
			['helmet_2'] = 0,
			['chain_1'] = 98,
			['chain_2'] = 0,
			['ears_1'] = -1,
			['ears_2'] = 0,
			['mask_1'] = 121,
			['mask_2'] = 0
		}
	},

	boss_wear = {
		male = {
			['tshirt_1'] = 31,
			['tshirt_2'] = 0,
			['torso_1'] = 31,
			['torso_2'] = 0,
			['decals_1'] = 0,
			['decals_2'] = 0,
			['arms'] = 4,
			['arms_2'] = 0,
			['pants_1'] = 28,
			['pants_2'] = 0,
			['shoes_1'] = 10,
			['shoes_2'] = 0,
			['helmet_1'] = -1,
			['helmet_2'] = 0,
			['chain_1'] = 18,
			['chain_2'] = 0,
			['ears_1'] = -1,
			['ears_2'] = 0,
			['mask_1'] = 0,
			['mask_2'] = 0
		},
		female = {
			['tshirt_1'] = 38,
			['tshirt_2'] = 0,
			['torso_1'] = 7,
			['torso_2'] = 0,
			['decals_1'] = 0,
			['decals_2'] = 0,
			['arms'] = 3,
			['arms_2'] = 0,
			['pants_1'] = 37,
			['pants_2'] = 0,
			['shoes_1'] = 0,
			['shoes_2'] = 0,
			['helmet_1'] = -1,
			['helmet_2'] = 0,
			['chain_1'] = 87,
			['chain_2'] = 4,
			['ears_1'] = -1,
			['ears_2'] = 0,
			['mask_1'] = 0,
			['mask_2'] = 0
		}
	}

}