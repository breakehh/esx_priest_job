# esx_priestjob

## Requirements
* [esx_billing](https://github.com/ESX-Org/esx_billing)
* [esx_society](https://github.com/ESX-Org/esx_society)
* [esx_datastore](https://github.com/ESX-Org/esx_datastore)
* [esx_identity](https://github.com/ESX-Org/esx_identity)
* [esx_license](https://github.com/ESX-Org/esx_license)
* [esx_service](https://github.com/ESX-Org/esx_service)

## Download
### Using [fvm-installer](https://github.com/qlaffont/fvm-installer)
```
fvm install --save --folder=esx esx-france/esx_priestjob
```

### Using [git](https://git-scm.com/)
```
cd resources
git clone https://github.com/ESX-FRANCE/esx_priestjob [esx]/esx_priestjob
```

### Manually
* [Download](https://github.com/ESX-FRANCE/esx_priestjob/archive/master.zip)
* Put it in your server resources folder.

## Installation
* Open **localization** folder then import ``your country_esx_priestjob.sql`` in your database.
* Also add ``start esx_priestjob`` in the **server.cfg** file.
