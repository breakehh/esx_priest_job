INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_church', 'Church', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_church', 'Church', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_church', 'Church', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('church','Church')
;

INSERT INTO `fine_types_priest` (label, amount, category) VALUES
	('Victim 1$',1,0),
	('Victim 2$',2,0),
	('Victim 3$',3,0),
	('Victim 4$',4,0),
	('Victim 5$',5,0),
	('Victim 10$',10,0),
	('Victim 15$',15,0),
	('Victim 20$',20,0),
	('Payment for the funeral 500$',500,0),
	('Mass payment',50,0)
;	

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('church',0,'ministrant','Acolyte',1000,'{}','{}'),
	('church',1,'vboss','Priest',1500,'{}','{}'),
	('church',2,'boss','Rector',2000,'{}','{}')
;
